#!/bin/bash
cp ../../test/ResultValidator.java out
javac -d out -Xlint:unchecked ./out/ResultValidator.java
java ResultValidator