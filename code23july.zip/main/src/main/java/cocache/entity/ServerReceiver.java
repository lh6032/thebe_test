package cocache.entity;

import cocache.simulation.Global;

import java.io.*;
import java.net.*;


/**
 * Server receive thread.
 * There are several threads, the total number of which is equal to
 * the number of all the clients.
 * <p>
 * The send thread will not be reused due to
 * an unexpected EOF exception.
 */
public class ServerReceiver extends Thread {
    public ServerSocket[] receiveSockets;
    private Server server;

    /**
     * @param server
     * @throws IOException port not available
     */
    public ServerReceiver( Server server ) throws IOException {
        this.server = server;
        receiveSockets = new ServerSocket[Global.clients.length];
        for (int i = 0; i < Global.clients.length; i++) {
            receiveSockets[i] = new ServerSocket( 0 );
            receiveSockets[i].setSoTimeout( 0 );
            Global.serverReceivePorts[i] = receiveSockets[i].getLocalPort();
        }
    }

    @Override
    public void run() {
        //all receivers started, start client sender
        for (int i = 0; i < Global.clients.length; i++) {
            final int index = i;
            new Thread( () -> {
                try {
                    new ServerReceiverHandler( receiveSockets[index].accept() ).start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } ).start();
        }
    }
}
