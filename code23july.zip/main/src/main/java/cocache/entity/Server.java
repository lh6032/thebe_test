package cocache.entity;

import cocache.communication.MessageToClient;
import cocache.communication.MessageToServer;
import cocache.data.Block;
import cocache.data.LRUCache_DLinkedList;
import cocache.simulation.Configuration;
import cocache.simulation.Global;
import cocache.simulation.SimulationCondition;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Server object
 * including a manager instance and a serverReceiver thread.
 */
public class Server {
    private static Server server = null;
    public Manager manager = null;
    public ServerReceiver serverReceiver = null;
    public LRUCache_DLinkedList<Block> cache;
    public volatile ObjectOutputStream[] outputStreamMap;

    //the age of  anew block
    public static AtomicInteger age = new AtomicInteger( 0 );

    private Server() throws IOException {
        this.restart();
    }

    /**
     * Mark if a block is a singlet.
     *
     * If the block is stored in over 2 client caches, then it is not a singlet, otherwise it is.
     *
     * @param block without singlet mark
     */
    public synchronized void markSinglet(Block block){
        Global.result.messageToServer ++;
        Global.result.messageFromServer ++;
        ConcurrentMap<Integer,Boolean> locations =  this.manager.locationGet( block.id );

        if(locations!=null && locations.keySet().size()>1){//this block is not a singlet
            block.recirculationCount = 0;
        }else{
            block.isSinglet = true;
            block.recirculationCount = Configuration.MAX_RECIRCULATION_COUNT;
        }
    }

    public void startServer() {
        serverReceiver.start();
    }

    public static Server getServer() throws IOException {
        if (server == null)
            server = new Server();
        return server;
    }

    public void restart() throws IOException {
        manager = new Manager();
        serverReceiver = new ServerReceiver( this );
        this.cache = new LRUCache_DLinkedList<Block>( Configuration.SERVER_CACHE_SIZE );
        this.outputStreamMap = new ObjectOutputStream[Global.clients.length];
    }

    public synchronized MessageToClient handleMessage( MessageToServer message, int blockId, int originalClientId, boolean forceDiskAccess ) {
        Global.result.messageToServer++;

        //the server must have a reply in any circumstances
        Global.result.messageFromServer++;

        MessageToClient respond = new MessageToClient();

        //if the block is in the server memory
        Block block = Global.cacheAccessibility[2] ? cache.get( blockId ) : null;

        if (block != null) {//local hit
            Global.result.serverCacheHitCount++;
            respond.setServerResponse( block, originalClientId );
            Global.algorithm.onServerSendingBlockBack(originalClientId, block);
            return respond;
        }

        //if the block is in the cooperative cache
        int clientId = Global.cacheAccessibility[1] ? getBlockRedirectClient( blockId, originalClientId ) : -1;

        if (message.isUnexpectedMiss) {
            //update the location information
            Global.algorithm.onUnexpectedClientCacheMiss( message );
        }

        if (clientId == originalClientId || clientId == -1 || forceDiskAccess) {//disk access
//            String r = "";
//            for(Map.Entry<Integer,Integer> entry : Global.server.manager.masterCopyLocation.entrySet()){
//                r+=entry.getKey()+" "+entry.getValue()+",";
//            }
//            Global.print( forceDiskAccess+"block"+blockId+"\n"+r );
            Global.result.diskAccessCount++;
            Block diskBlock = new Block( blockId );
            diskBlock.age = age.incrementAndGet();
            cache.set( diskBlock );
            Global.algorithm.onServerSendingBlockBack(originalClientId, diskBlock);
            respond.setServerResponse(diskBlock , originalClientId );
        } else {
            respond.setRedirectFromServer( blockId, originalClientId, clientId );
        }

        if(message.isUnexpectedMiss){
            Global.print( "On an unexpected cache miss, server send back message:"+respond );
        }

        return respond;
    }

    public void cacheChange( int clientId, int discardedBlockId, int savedBlock ) {
        Global.result.messageToServer++;

        if (discardedBlockId != -1) {
            ConcurrentMap<Integer,Boolean> locationMap = manager.locationGet( discardedBlockId );
            if(locationMap!=null)
                locationMap.remove( Integer.valueOf( clientId ) );
        }

        if (savedBlock != -1) {
            if (!manager.location.containsKey( savedBlock )) {
                ConcurrentMap<Integer, Boolean> clientList = new ConcurrentHashMap<Integer, Boolean>();
                clientList.put( clientId, false );
                manager.locationPut( savedBlock, clientList );
            } else {
                manager.locationGet( savedBlock ).put( clientId, false );
            }
        }
    }

    /**
     * Only stores the possible location of master copy
     * @param clientId
     * @param blockId
     */
    public void cacheChangeForMasterCopy( int clientId, int blockId ) {
        manager.masterCopyLocation.put( blockId, clientId );
    }

    /**
     * Get the client where the block should be stored at
     *
     * @param blockId
     * @return if no client found, return -1, otherwise return clientId
     */
    public int getBlockRedirectClient( int blockId, int originalClientId ) {
        return Global.algorithm.getServerRedirectClient( manager, blockId, originalClientId );
    }
}
