package cocache.communication;

import java.io.Serializable;

public class MessageToServer implements Serializable {
    private static final long serialVersionUID = 42L;

    //if the message is a stop message, it contains no data, just to inform the server that the client stops sending requests
    public int blockId = -1;
    public int originalClientId = -1;
    public int senderId = -1;
    public boolean isUnexpectedMiss = false;
    public boolean isHelloMessage = false;
    public boolean isTemporary = false;

    //force the server to find the block in the disk
    public boolean forceDiskAccess;

    public MessageToServer( int blockId, int originalClientId, boolean forceDiskAccess ) {
        this.blockId = blockId;
        this.originalClientId = originalClientId;
        this.forceDiskAccess = forceDiskAccess;
    }

    @Override
    public String toString() {
        return "MessageToServer{" +
                "blockId=" + blockId +
                ", originalClientId=" + originalClientId +
                ", senderId=" + senderId +
                ", isUnexpectedMiss=" + isUnexpectedMiss +
                ", isHelloMessage=" + isHelloMessage +
                ", forceDiskAccess=" + forceDiskAccess +
                '}';
    }
}
