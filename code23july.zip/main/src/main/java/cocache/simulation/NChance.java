package cocache.simulation;

import cocache.communication.MessageToClient;
import cocache.communication.MessageToServer;
import cocache.data.Block;
import cocache.entity.Client;
import cocache.entity.Manager;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class NChance implements Algorithm {

    /**
     * Same as greedy forwarding algorithm.
     * Put random blocks into client and server cache and use server manager to track the location information.
     */
    @Override
    public void warmUp(){
        for (int i = 0; i < Global.clients.length; i++) {
            for (int j = 0; j < Configuration.CLIENT_CACHE_SIZE; j++) {
                Block block = new Block( (int) (Math.random() * Configuration.TOTAL_BLOCKS) );
                Global.clients[i].cache.set(block);
                if(Global.server.manager.location.containsKey( block.id )){
                    Global.server.manager.location.get( block.id ).put( i,false );
                }else{
                    ConcurrentMap<Integer, Boolean> clients = new ConcurrentHashMap<Integer, Boolean>(  );
                    clients.put( i,false );
                    Global.server.manager.location.put( block.id, clients);
                }
            }
        }

        for (int i = 0; i < Configuration.SERVER_CACHE_SIZE; i++) {
            Global.server.cache.set( new Block( (int) (Math.random() * Configuration.TOTAL_BLOCKS) ) );
        }
    }

    /**
     * Do nothing
     * @param clientId
     * @param block
     */
    @Override
    public void onServerSendingBlockBack( int clientId, Block block ) { }

    @Override
    public MessageToClient onClientReceiveBlockRespond( boolean isFromServer, Client client, Block block ) {
        Block discardedBlock = client.cache.set( block );

        if (discardedBlock == null) return null;

        MessageToClient forwardMessage = null;
        Global.result.messageFromClient++;
        Global.server.cacheChange( client.id, discardedBlock != null ? discardedBlock.id : -1, block.id );

        if (!discardedBlock.isSinglet) {
            Global.server.markSinglet( discardedBlock );
        }

        if (discardedBlock.recirculationCount > 0) {
            discardedBlock.recirculationCount--;
            forwardMessage = new MessageToClient();
            forwardMessage.setForwardedFromClient( discardedBlock, Global.algorithm.getBlockForwardClient( client, discardedBlock ), client.id );
        }
        return forwardMessage;
    }

    /**
     * Same as the GreedyForwarding algorithm
     *
     * @param manager
     * @param blockId
     * @param originalClientId
     * @return
     */
    @Override
    public synchronized int getServerRedirectClient( Manager manager, int blockId, int originalClientId ) {
        ConcurrentMap<Integer, Boolean> list = manager.locationGet( blockId );
        if (list == null || list.isEmpty()) {
            return -1;
        } else {
            Iterator<Integer> iterator = list.keySet().iterator();
            while (iterator.hasNext()) {
                int cur = iterator.next();
                if (cur != originalClientId) {
                    return cur;
                }
            }
            return -1;
        }
    }

    /**
     * Same as the GreedyForwarding algorithm
     *
     * @param messageToServer
     */
    @Override
    public synchronized void onUnexpectedClientCacheMiss( MessageToServer messageToServer ) {
        ConcurrentMap<Integer, Boolean> blockLocations = Global.server.manager.locationGet( messageToServer.blockId );
        if (blockLocations != null)
            blockLocations.remove( messageToServer.senderId );
    }

    /**
     * The same as Greedy Forwarding algorithm.
     *
     * @param result  local cache hit result, null if cache miss
     * @param message message redirected to the current client
     * @param client  current client
     * @return null if the block is not found, or a message containing that block to the original client
     */
    @Override
    public MessageToClient handleRedirectedRequestResult( Block result, MessageToClient message, Client client ) {
        MessageToClient respond = null;
        if (result != null) {
            respond = new MessageToClient();
            Global.result.globalCacheHitCount++;
            Block copiedBlock = result.clone();
            respond.senderId = client.id;
            respond.setClientResponse( copiedBlock, message.originalClientId );
        }

        return respond;
    }

    /**
     * When the client the block forwarded from other client's cache,
     * it simply stores that block in its cache and discard any block which is dropped.
     * It is to prevent a chain reaction.
     *
     * Another block forward will not happen in NChance forwarding algorithm.
     *
     * @param client         current client
     * @param forwardMessage message containing the forwarded block
     */
    @Override
    public synchronized MessageToClient handleForwardedBlock( Client client, MessageToClient forwardMessage ) {
        Global.result.messageFromClient++;
        Block discardedBlock = client.cache.set( forwardMessage.block );
        Global.server.cacheChange( client.id, discardedBlock != null ? discardedBlock.id : -1, forwardMessage.blockId );
        return null;
    }

    /**
     * Discarded block will be forwarded to a random client other than itself.
     */
    @Override
    public int getBlockForwardClient( Client client, Block block ) {
        int res = client.id;
        while (Global.clients.length>1 && res == client.id) {
            res = (int) (Math.random() * Global.clients.length);
        }

        return res;
    }
}
