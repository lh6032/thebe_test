package cocache.simulation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;

public class Configuration {
    public static final int LOCAL_CACHE_HIT_TICK = 1;
    public static final int GLOBAL_CACHE_HIT_TICK = 1;
    public static final int COMMUNICATION_TICK= 1;
    public static final int SERVER_CACHE_HIT_TICK = 1;
    public static final int SERVER_MANAGER_OPERATION_TICK = 1;
    public static final int SERVER_DISK_ACCESS_TICK = 10;

    public static final int MAXIMUM_CLIENT_FORWARD = 4;

    public static boolean USE_EXISTING_TRACE_FILE;
    public static int TOTAL_BLOCKS;
    public static int CLIENT_CACHE_SIZE;
    public static int SERVER_CACHE_SIZE;
    public static int CLIENT_NUMBER;
    public static int ITERATION_COUNT = 1;
    public static boolean ONLY_PRINT_RECEIVE_LOG = false;
    public static int REQUEST_PER_CLIENT;
    public static int LOCALIZATION_FACTOR;
    public static int MAX_RECIRCULATION_COUNT = 2;
    public static ALGORITHM_TYPES ALGORITHM;
    public static SimulationCondition simulationCondition = SimulationCondition.NORMAL;

    public static int changeEnd = 0;
    public static int changeStart = 0;

    private static String changeVariable = "";

    /**
     * Change the setting automatically after each iteration.
     *
     * There could be at most one variable that going to change.
     *
     * All the result values must be integers.
     *
     * If there is only one iteration, this method should not be invoked.
     */
    public static void change(){
        int newValue = changeStart + (int) ((changeEnd - changeStart) * ((float)Global.currentIteration) / (ITERATION_COUNT - 1));
        if("TOTAL_BLOCKS".equals( changeVariable )){
            TOTAL_BLOCKS = newValue;
        }

        if("CLIENT_CACHE_SIZE".equals( changeVariable )){
            CLIENT_CACHE_SIZE = newValue;
        }

        if("SERVER_CACHE_SIZE".equals( changeVariable )){
            SERVER_CACHE_SIZE = newValue;
        }

        if("CLIENT_NUMBER".equals( changeVariable )){
            CLIENT_NUMBER = newValue;
        }

        if("REQUEST_PER_CLIENT".equals( changeVariable )){
            REQUEST_PER_CLIENT = newValue;
        }

        if("LOCALIZATION_FACTOR".equals( changeVariable )){
            LOCALIZATION_FACTOR = newValue;
        }

        if("MAX_RECIRCULATION_COUNT".equals( changeVariable )){
            MAX_RECIRCULATION_COUNT = newValue;
        }
    }

    public static int readAndGetInitial(String variable, String valueStr){
        int start,end;
        if(valueStr.indexOf( "," )!=-1){
            changeVariable = variable;
            String range[] = valueStr.split( "," );
            start = Integer.parseInt( range[0] );
            end = Integer.parseInt( range[1] );
            changeEnd = end;
            changeStart = start;
        }else{
            start = Integer.parseInt( valueStr );
        }
        return start;
    }

    public static void readFromFile(String name) throws IOException {
        InputStream is = Configuration.class.getResourceAsStream( "/"+name );
        BufferedReader br = new BufferedReader( new InputStreamReader( is ) );
        List<String> lineList = br.lines().collect( Collectors.toList());
        lineList.forEach( line->{
            String strs[] = line.split( "=" );
            if("ITERATION_COUNT".equals(strs[0])){
                ITERATION_COUNT = Integer.parseInt( strs[1] );
            }
        });

        lineList.forEach( line->{
            String strs[] = line.split( "=" );
            if("TOTAL_BLOCKS".equals(strs[0])){
                TOTAL_BLOCKS = readAndGetInitial(strs[0], strs[1]);
            }else if("USE_EXISTING_TRACE_FILE".equals(strs[0])){
                USE_EXISTING_TRACE_FILE = Integer.parseInt( strs[1] )==1;
            }else if("CLIENT_CACHE_SIZE".equals(strs[0])){
                CLIENT_CACHE_SIZE = readAndGetInitial(strs[0], strs[1]);
            }else if("SERVER_CACHE_SIZE".equals(strs[0])){
                SERVER_CACHE_SIZE = readAndGetInitial(strs[0], strs[1]);
            }else if("CLIENT_NUMBER".equals(strs[0])){
                CLIENT_NUMBER = readAndGetInitial(strs[0], strs[1]);
            }else if("REQUEST_PER_CLIENT".equals(strs[0])){
                REQUEST_PER_CLIENT = readAndGetInitial(strs[0], strs[1]);
            }else if("MAX_RECIRCULATION_COUNT".equals(strs[0])){
                MAX_RECIRCULATION_COUNT = readAndGetInitial(strs[0], strs[1]);
            }else if("ONLY_PRINT_RECEIVE_LOG".equals(strs[0])){
                ONLY_PRINT_RECEIVE_LOG = Integer.parseInt( strs[1] )==1;
            }else if("LOCALIZATION_FACTOR".equals(strs[0])){
                LOCALIZATION_FACTOR = readAndGetInitial(strs[0], strs[1]);
            }else if("ALGORITHM".equals(strs[0])){
                ALGORITHM = ALGORITHM_TYPES.valueOf( strs[1] );
                if (ALGORITHM == ALGORITHM_TYPES.GREEDY_FORWARDING){
                    Global.algorithm = new GreedyForwarding();
                }

                if (ALGORITHM == ALGORITHM_TYPES.N_CHANCE){
                    Global.algorithm = new NChance();
                }

                if (ALGORITHM == ALGORITHM_TYPES.HINT_BASED){
                    Global.algorithm = new HintBased();
                }
            }else if("SIMULATION_CONDITION".equals(strs[0])){
                simulationCondition = SimulationCondition.valueOf( strs[1] );
                if(simulationCondition == SimulationCondition.ONLY_SERVER_CACHE){
                    Global.cacheAccessibility[0] = false;
                    Global.cacheAccessibility[1] = false;
                }

                if(simulationCondition == SimulationCondition.ONLY_GLOBAL_CACHE){
                    Global.cacheAccessibility[0] = false;
                    Global.cacheAccessibility[2] = false;
                }

                if(simulationCondition == SimulationCondition.ONLY_SERVER_DISK){
                    Global.cacheAccessibility[0] = false;
                    Global.cacheAccessibility[1] = false;
                    Global.cacheAccessibility[2] = false;
                }
            }
        } );
    }
}
