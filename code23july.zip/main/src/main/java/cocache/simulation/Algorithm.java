package cocache.simulation;

import cocache.communication.MessageToClient;
import cocache.communication.MessageToServer;
import cocache.data.Block;
import cocache.entity.Client;
import cocache.entity.Manager;

public interface Algorithm {
    /**
     * For different algorithms, warm up phase could be different
     */
    void warmUp();

    void onServerSendingBlockBack(int clientId, Block block);
    /**
     * Happens when a client cache changes
     *
     * @param client
     * @param block saved block
     */
    MessageToClient onClientReceiveBlockRespond( boolean isFromServer, Client client, Block block);

    int getServerRedirectClient( Manager manager, int blockId, int originalClientId );

    /**
     * How to deal with the unexpected client cache miss
     */
    void onUnexpectedClientCacheMiss( MessageToServer messageToServer );

    /**
     * How to deal with the result from redirected request
     *
     * @param result local cache hit result, null if cache miss
     */
    MessageToClient handleRedirectedRequestResult( Block result, MessageToClient message, Client client );

    /**
     * How to deal with the forwarded block
     *
     * @param client current client
     * @param forwardMessage message containing the forwarded blcok
     */
    MessageToClient handleForwardedBlock(Client client, MessageToClient forwardMessage);

    /**
     * Get the client where the block should be forwarded to.
     *
     * Only in the algorithm that coordinate cache contents will redirect block
     * to a specific client.
     *
     * @param client current client
     * @param block discarded block.
     * @return if no client found, return -1, otherwise return clientId
     */
    int getBlockForwardClient( Client client, Block block );
}
