package cocache.simulation;

import cocache.communication.MessageToClient;
import cocache.communication.MessageToServer;
import cocache.data.Block;
import cocache.entity.Client;
import cocache.entity.Manager;

public class HintBased implements Algorithm {

    /**
     * Only use manager to track the location of master copy.
     */
    @Override
    public void warmUp(){
        for (int i = 0; i < Global.clients.length; i++) {
            for (int j = 0; j < Configuration.CLIENT_CACHE_SIZE; j++) {
                Block block = new Block( (int) (Math.random() * Configuration.TOTAL_BLOCKS) );
                block.isMasterCopy = true;
                Global.clients[i].cache.set(block);
                Global.server.cacheChangeForMasterCopy( i, block.id );
            }
        }

        for (int i = 0; i < Configuration.SERVER_CACHE_SIZE; i++) {
            Global.server.cache.set( new Block( (int) (Math.random() * Configuration.TOTAL_BLOCKS) ) );
        }
    }

    @Override
    public void onServerSendingBlockBack( int clientId, Block block ) {
        block.isMasterCopy = true;
        Global.server.cacheChangeForMasterCopy( clientId, block.id );
        Global.print( "Server cache changed as master copy block"+block.id+" is stored at client"+clientId );
    }

    /**
     * Forward the discarded to a client which the current client believes hold the oldest block
     * @param client
     * @param block saved block
     * @return
     */
    @Override
    public MessageToClient onClientReceiveBlockRespond( boolean isFromServer, Client client, Block block ) {
        Block discardedBlock = client.cache.set( block );

        if (discardedBlock==null) return null;

        MessageToClient forwardMessage = null;

        int destination = Global.algorithm.getBlockForwardClient( client,discardedBlock );

        if(discardedBlock.isMasterCopy){//next jump of that master copy
            client.masterCopyForwardDestination[discardedBlock.id] = destination + 1;
        }

        if(destination == client.id){//the client itself holds the oldest block
            Block throwed = client.cache.set( discardedBlock );

            //clear the next jump of the throwed master copy
            if(throwed.isMasterCopy)
                client.masterCopyForwardDestination[throwed.id] = 0;

            client.ageTable.update();
        }else{//other client holds the oldest block, forward the discarded block and exchange the age table
            forwardMessage = new MessageToClient();
            forwardMessage.setForwardedFromClient(discardedBlock,destination, client.id);
            forwardMessage.ageTable = client.ageTable;
        }

        return forwardMessage;
    }

    /**
     * Here the manager only provide master copy location
     *
     * @param manager
     * @param blockId
     * @param originalClientId
     * @return
     */
    @Override
    public synchronized int getServerRedirectClient( Manager manager, int blockId, int originalClientId ) {
        Integer dest = Global.server.manager.masterCopyLocation.get( blockId );
        return dest==null?-1:dest.intValue();
    }

    /**
     * Since the manager does not provide accurate location of master copy,
     * it's possible that after several redirections, the master copy is still not found.
     *
     * In that case, it's not an "unexpected" cache miss, and the manager don't have to
     * change anything.
     *
     * @param messageToServer
     */
    @Override
    public void onUnexpectedClientCacheMiss( MessageToServer messageToServer ) {

    }

    /**
     * Client receives redirection from the server.
     * The redirection may not be accurate in this algorithm,
     * so even if the result is null, as long as the message didn't hit the redirection limit,
     * there is still another redirection message.
     *
     * Only when the client don't know where to redirect the request or the message
     * hit the redirection limit, will the result be null.
     *
     * @param result local cache hit result, null if cache miss
     * @param message null if no further redirection is needed
     * @param client current client
     * @return
     */
    @Override
    public MessageToClient handleRedirectedRequestResult( Block result, MessageToClient message, Client client ) {
        MessageToClient respond = null;

        if (result!=null){
            //global cache hit
            respond = new MessageToClient();
            Global.result.globalCacheHitCount++;
            Block copiedBlock = result.clone();
            respond.senderId = client.id;
            respond.setClientResponse( copiedBlock,message.originalClientId );
        }else{
            if (message.forwardCount < Configuration.MAXIMUM_CLIENT_FORWARD){
                int nextClient = client.masterCopyForwardDestination[message.blockId] - 1;

                if(nextClient>-1){
                    respond = new MessageToClient();
                    respond.isClientRedirected = true;
                    respond.originalClientId = message.originalClientId;
                    respond.senderId = client.id;
                    respond.blockId = message.blockId;
                    respond.ageTable = client.ageTable;
                    respond.forwardCount = message.forwardCount + 1;
                    respond.clientId = nextClient;
                }else{
//                    String t = "";
//                    for (int i = 0; i < client.masterCopyForwardDestination.length; i++) {
//                        if(client.masterCopyForwardDestination[i]!=0){
//                            t+=i+" "+client.masterCopyForwardDestination[i]+",";
//                        }
//                    }
                    Global.print( "client"+client.id+" can not find the next jump of block"+message.blockId);
                }
            }else{
                Global.result.maximumForwardExceedCount++;
            }
        }

        return respond;
    }

    /**
     * Handle the forwarded block.
     * Since the current client is chosen to be the client with the oldest block,
     * the discarded block is believed to be the least valuable block which
     * should be discarded in the global cache.
     *
     * There will not be further forward of the discarded block.
     * Client will not inform the manager about client cache change since
     * the location information provided by manager is already inaccurate.
     *
     * The client wil only update its own master copy location table if that is a master copy.
     *
     * @param client current client
     * @param forwardMessage message containing the forwarded blcok
     */
    @Override
    public MessageToClient handleForwardedBlock( Client client, MessageToClient forwardMessage ) {
        Global.result.messageFromClient++;
        Block throwed = client.cache.set( forwardMessage.block );

        if (throwed!=null && throwed.isMasterCopy){
            client.masterCopyForwardDestination[throwed.id] = 0;
        }
        return null;
    }

    @Override
    public int getBlockForwardClient( Client client, Block block ) {
        return client.ageTable.getOldestBlockClientId();
    }
}
