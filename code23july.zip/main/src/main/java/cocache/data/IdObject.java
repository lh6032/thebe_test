package cocache.data;

public interface IdObject<T> {
    int getId();
    long getLastUsed();
    void setLastUsed(long tick);
    T clone();
}
