### Configuration
Configuration file is inside the ```src/main/resource```, for each line, there is a key value pair separated by "=" without any space around.
### Start
Compile and run Start.java