package cocache.data;

import java.io.Serializable;

/**
 * Block object, stores an integer id variable.
 * Some variables are related to specific algorithm.
 */
public class Block implements IdObject<Block>, Serializable {
    private static final long serialVersionUID = 42L;

    public int id;
    public int age = 0;
    public long lastUsed;

    public boolean isMasterCopy = false;
    public boolean isSinglet = false;

    /**
     * Recirculation count used in N-Chance Forwarding algorithm
     *
     * if this value is -1, then the block has not been marked as a singlet
     *
     * if this value is 0, this block should be discarded, either because it's a singlet
     * which exceeds the maximum recirculation time, or it's not a singlet.
     */
    public int recirculationCount = -1;

    public Block( int id ) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Block{" +
                "dataId=" + id +
                '}';
    }

    @Override
    public boolean equals( Object obj ) {
        return ((Block)obj).id == this.id;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public long getLastUsed() {
        return lastUsed;
    }

    @Override
    public void setLastUsed( long tick ) {
        this.lastUsed = tick;
    }

    @Override
    public Block clone() {
        Block res = new Block( id );
        res.age = this.age;
        return res;
    }
}
