package cocache.data;

import cocache.simulation.Configuration;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * LRUCache implementation using double linked list
 *
 * @param <T> Element type
 */
public class LRUCache_DLinkedList<T extends IdObject<T>> {
    private Map<Integer, DLinkedList<T>> map;
    private DLinkedList<T> fhead;
    private DLinkedList<T> end;
    private int capacity;
    public int size;

    @Override
    public String toString() {
        List<Integer> res = new ArrayList<Integer>();
        DLinkedList<T> cur = fhead.next;
        while (cur != null) {
            res.add( cur.element.getId() );
            cur = cur.next;
        }
        res.sort( Comparator.naturalOrder() );
        return res.toString();
    }

    public T peek() {
        return fhead.next != null ? fhead.next.element : null;
    }

    public LRUCache_DLinkedList( int capacity ) {
        end = fhead = new DLinkedList<T>();
        this.capacity = capacity;
        this.size = 0;
        this.map = new ConcurrentHashMap<Integer, DLinkedList<T>>();
    }

    public synchronized T set( T t ) {
        T removed = null;

        if (map.containsKey( t.getId() )) {
            DLinkedList<T> node = map.get( t.getId() );
            //move to tail
            if (node != end) {
                node.moveOut();
                node.prev = end;
                end = end.next = node;
            }
        } else {
            DLinkedList<T> node = new DLinkedList<T>( t );
            map.put( t.getId(), node );
            if (capacity == size) {//remove the first
                DLinkedList<T> removedNode = fhead.next;
                removedNode.moveOut();
                removed = removedNode.element;
                map.remove( removed.getId() );

                if (size == 1) {
                    end = fhead;
                }
            } else {
                size++;
            }

            //add to tail

            node.prev = end;
            end = end.next = node;
        }
        return removed;
    }

    public synchronized T get( int id ) {
        T res = null;
        if (map.containsKey( id )) {
            res = map.get( id ).element;
            this.set( res );
        }

        return res;
    }


    public static void main( String[] args ) {
        int totalBlock = 50, capacity = 1, totalRequest = 1000;
        Configuration.TOTAL_BLOCKS = totalBlock;

        LRU_LinkedHashMap standard = new LRU_LinkedHashMap( capacity );
        LRUCache_DLinkedList<Block> mine = new LRUCache_DLinkedList<Block>( capacity );

        //in the test, key does not matter
        int[] a = new int[totalRequest];
        boolean[] operation = new boolean[totalRequest];

        for (int i = 0; i < totalRequest; i++) {
            a[i] = (int) (Math.random() * totalBlock);
            operation[i] = Math.random() > .5 ? true : false;
        }

        for (int i = 0; i < totalRequest; i++) {
            int standardResult = -1, myResult = -1;
            if (operation[i]) {
                standardResult = standard.get( a[i] );
                Block o = mine.get( a[i] );
                if (o == null) {
                    myResult = -1;
                } else {
                    myResult = o.id;
                }
            } else {
                standard.put( a[i], a[i] );
                mine.set( new Block( a[i] ) );
            }

            if (myResult != standardResult) {
                System.out.println( "ERROR" );
                break;
            }
        }
    }
}
