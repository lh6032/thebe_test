package cocache.data;

import cocache.simulation.Configuration;

import java.lang.reflect.Array;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * LRUCache without using a map
 * <p>
 * Not thread-safe
 *
 * @param <T>
 */
public class LRUCache_Array<T extends IdObject<T>> {
    private int size;
    private int capacity;
    private Object[] used;
    private long[] lastUsed;
    private long ticker;

    public Deque<T> q;

    public LRUCache_Array( int capacity ) {
        this.capacity = capacity;
        used = new Object[Configuration.TOTAL_BLOCKS];
        lastUsed = new long[Configuration.TOTAL_BLOCKS];
        q = new ConcurrentLinkedDeque<T>();
    }

    public int getCapacity() {
        return capacity;
    }

    public int getSize() {
        return size;
    }

    /**
     * Since
     */
    private void cleanHead() {
        while (q.size() > 0 && q.peekFirst().getLastUsed() < lastUsed[q.peekFirst().getId()]) {
            q.pollFirst();
        }
    }

    /**
     * Set an element in the cache
     * add the element to head whether or not
     * that element exists.
     * <p>
     * Remove the element on the tail if size exceeds
     * the capacity.
     *
     * @param t
     * @return removed element if any
     */
    public T set( T t ) {
        T removed = null;
        t = t.clone();
        q.offerLast( t );
        ticker++;
        lastUsed[t.getId()] = ticker;
        t.setLastUsed( ticker );

        //new object added
        if (used[t.getId()] == null) {
            used[t.getId()] = t;
            size++;
        }

        //should remove head element
        if (size > capacity) {
            cleanHead();
            removed = q.size() > 0 ? q.pollFirst() : null;
            if (removed != null) {
                size--;
                lastUsed[removed.getId()] = 0;
                used[removed.getId()] = null;
            }
        }

        return removed;
    }

    /**
     * Get the element to be removed
     *
     * @return the element should to be removed
     */
    public T peek() {
        cleanHead();

        return q.size() > 0 ? q.peekFirst() : null;
    }

    /**
     * Get an element by id
     *
     * @param id
     * @return element
     */
    public T get( int id ) {
        T cur = (T) used[id];
        if (cur != null) {
            set( cur );
        }

        return cur != null ? cur.clone() : null;
    }

    public static void main( String[] args ) {
        int totalBlock = 50, capacity = 20, totalRequest = 1000;
        Configuration.TOTAL_BLOCKS = totalBlock;

        LRU_LinkedHashMap standard = new LRU_LinkedHashMap( capacity );
        LRUCache_Array<Block> mine = new LRUCache_Array( capacity );

        //in the test, key does not matter
        int[] a = new int[totalRequest];
        boolean[] operation = new boolean[totalRequest];

        for (int i = 0; i < totalRequest; i++) {
            a[i] = (int) (Math.random() * totalBlock);
            operation[i] = Math.random()>.5?true:false;
        }

        for (int i = 0; i < totalRequest ; i++) {
            int standardResult = -1, myResult = -1;
            if(operation[i]){
                standardResult = standard.get( a[i] );
                Block o = mine.get( a[i] );
                if(o==null){
                    myResult = -1;
                }else{
                    myResult = o.id;
                }
            }else{
                standard.put( a[i],a[i] );
                mine.set(new Block( a[i] ));
            }

            if(myResult!=standardResult){
                break;
            }
        }
    }
}
