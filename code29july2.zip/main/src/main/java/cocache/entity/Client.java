package cocache.entity;

import cocache.communication.MessageToServer;
import cocache.communication.MessageToClient;
import cocache.data.Block;
import cocache.data.BlockAgeTable;
import cocache.data.LRUCache_DLinkedList;
import cocache.simulation.Configuration;
import cocache.simulation.Global;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Simulatied Client in the cooperative caching network
 * Each client has its own cache and do the block forwarding,
 * block redirecting and block request sending
 * based the trace files and different strategies or algorithms.
 * <p>
 * Using thread in JVM to do the simulation.
 */
public class Client {
    public int id;

    public LRUCache_DLinkedList<Block> cache;
    public Deque<ClientTrace> traces;
    public ClientReceiver clientReceiver;
    public ClientSender clientSender;
    public ClientServerConnectionBuilder connectionBuilder;
    public BlockAgeTable ageTable;
    public int[] masterCopyForwardDestination;//1-based index

    public Client( int id ) throws IOException {
        this.id = id;
        this.restart();
        ageTable = new BlockAgeTable( this );
        this.masterCopyForwardDestination = new int[Configuration.TOTAL_BLOCKS];
    }

    public void restart() throws IOException {
        this.cache = new LRUCache_DLinkedList<Block>( Configuration.CLIENT_CACHE_SIZE );
        this.traces = new ArrayDeque<ClientTrace>();
        this.clientSender = new ClientSender( this );
        this.clientReceiver = new ClientReceiver( this );
        this.connectionBuilder = new ClientServerConnectionBuilder( this );
        this.ageTable = new BlockAgeTable( this );
        this.masterCopyForwardDestination = new int[Configuration.TOTAL_BLOCKS];
    }

    /**
     * For each trace, query data block on the local cache
     * If data block not found, send a request to server
     *
     * @param trace
     */
    public MessageToServer consumeTrace( ClientTrace trace ) {
        MessageToServer requestToServer = null;
        Block block = Global.cacheAccessibility[0] ? cache.get( trace.block.id ) : null;
        if (block != null) {//local hit
            Global.print( "Client"+id+" local cache hit of block"+block.id,true );
            Global.result.localCacheHitCount++;
        } else {
            //request block from server
            Global.result.messageFromClient++;
            requestToServer = new MessageToServer( trace.block.id, id, false );
            requestToServer.senderId = id;
            if (traces.size() == 0){
                requestToServer.isLastBlockRequest = true;
            }
        }
        return requestToServer;
    }

    public MessageToClient receiveBlockRespond( boolean isFromServer, Block block ) {
        Global.result.messageToClient++;

        return Global.algorithm.onClientReceiveBlockRespond( isFromServer, this, block );
    }

    /**
     * Handle the redirected request from server or client
     *
     * @param message mesage sent to the current client
     */
    public MessageToClient acceptRedirectedRequest( MessageToClient message ) {
        Global.result.messageToClient++;
        Block result = cache.get( message.blockId );

        return Global.algorithm.handleRedirectedRequestResult( result, message, this );
    }

    /**
     * Accept the forwarded block.
     * <p>
     * There will not be further communications caused by the forwarded block.
     */
    public MessageToClient acceptForwardedBlock( MessageToClient message ) {
        Global.result.messageToClient++;

        return Global.algorithm.handleForwardedBlock( this, message );
    }
}
