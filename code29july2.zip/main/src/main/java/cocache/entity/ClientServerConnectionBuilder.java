package cocache.entity;

import cocache.communication.MessageToServer;
import cocache.simulation.Global;
import cocache.util.Util;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientServerConnectionBuilder extends Thread {
    private Client client;

    public ClientServerConnectionBuilder( Client client ) {
        this.client = client;
    }

    @Override
    public void run() {
        //establishing connection between client and thread
        try {
            Socket socket = Util.getAvailableSocket( client.id, Global.localAddress, Global.serverReceivePorts[this.client.id] );
            this.client.clientSender.toServerSocket = socket;
            Global.clientSenderPortMap.put( socket.getLocalPort(), this.client.id );
            this.client.clientSender.toServerOutputStream = new ObjectOutputStream( socket.getOutputStream() );
            new ClientReceiverHandler( client, socket ).start();
        } catch (IOException e) {
            System.out.println( "Building connection from client to server failed." );
            e.printStackTrace();
        }

        //send an empty message to ensure the objectOutputStream in the server is stored
        if (Global.connectedClients.incrementAndGet() == Global.clients.length) {
            for (int i = 0; i < Global.clients.length; i++) {
                MessageToServer helloMessage = new MessageToServer( 0, 0, false );
                helloMessage.senderId = client.id;
                helloMessage.isHelloMessage = true;
                try {
                    Global.clients[i].clientSender.writeToOutputStream( helloMessage );
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
