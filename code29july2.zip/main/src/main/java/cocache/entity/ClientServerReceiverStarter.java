package cocache.entity;

import cocache.simulation.Global;

public class ClientServerReceiverStarter extends Thread {
    private boolean isClient;
    private int clientId;

    public ClientServerReceiverStarter( boolean isClient, int clientId ) {
        this.isClient = isClient;
        this.clientId = clientId;
    }

    @Override
    public void run() {
        if(isClient){
            Global.clients[clientId].clientReceiver.start();
        }else{
            Global.server.serverReceiver.start();
        }

        if (Global.startedNodes.incrementAndGet() == Global.clients.length + 1) {
            for (Client client : Global.clients) {
                client.connectionBuilder.start();
            }
        }
    }
}
