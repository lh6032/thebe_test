package cocache.simulation;

public enum ALGORITHM_TYPES {
    GREEDY_FORWARDING("GREEDY_FORWARDING"),
    N_CHANCE("N_CHANCE"),
    HINT_BASED("HINT_BASED"),
    ;
    private String name;

    ALGORITHM_TYPES( String name ) {
        this.name = name;
    }
}
