package cocache.simulation;

import cocache.communication.MessageToClient;
import cocache.communication.MessageToServer;
import cocache.data.Block;
import cocache.entity.Client;
import cocache.entity.Manager;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class GreedyForwarding implements Algorithm {
    /**
     * Put random blocks into client and server cache and use server manager to track the location information.
     */
    @Override
    public void warmUp(){
        for (int i = 0; i < Global.clients.length; i++) {
            for (int j = 0; j < Configuration.CLIENT_CACHE_SIZE; j++) {
                Block block = new Block( (int) (Math.random() * Configuration.TOTAL_BLOCKS) );
                Global.clients[i].cache.set(block);
                if(Global.server.manager.location.containsKey( block.id )){
                    Global.server.manager.location.get( block.id ).put( i,false );
                }else{
                    ConcurrentMap<Integer, Boolean> clients = new ConcurrentHashMap<Integer, Boolean>(  );
                    clients.put( i,false );
                    Global.server.manager.location.put( block.id, clients);
                }
            }
        }

        for (int i = 0; i < Configuration.SERVER_CACHE_SIZE; i++) {
            Global.server.cache.set( new Block( (int) (Math.random() * Configuration.TOTAL_BLOCKS) ) );
        }
    }

    /**
     * Do nothing
     * @param clientId
     * @param block
     */
    @Override
    public void onServerSendingBlockBack( int clientId, Block block ) { }

    /**
     * notify server about client cache change
     * but do not forward the discarded block to anywhere else
     * @param client owner client
     * @param block
     * @return Return a messageToClient to the forward destination if the discarded block need to be forwarded, else return null
     */
    @Override
    public MessageToClient onClientReceiveBlockRespond( boolean isFromServer, Client client, Block block ) {
        Block discardedBlock = client.cache.set( block );
        Global.result.messageFromClient++;
        Global.server.cacheChange( client.id, discardedBlock!=null?discardedBlock.id:-1, block.id );
        return null;
    }

    /**
     * Return the redirected client that might has the block
     * the block can not be the original client which sent the request.
     * However, in some special tests, a client could skip local cache search.
     *
     * @param manager block location manager
     * @param blockId
     * @param originalClientId
     * @return
     */
    @Override
    public synchronized int getServerRedirectClient( Manager manager, int blockId, int originalClientId ) {
        ConcurrentMap<Integer,Boolean> list = manager.locationGet( blockId );
        if(list == null || list.isEmpty()){
            return -1;
        }else{
            Iterator<Integer> iterator = list.keySet().iterator();
            while (iterator.hasNext()){
                int cur = iterator.next();
                if (cur!=originalClientId){
                    return cur;
                }
            }
            return -1;
        }
    }
    /**
     * Happens when the manager provides inaccurate information
     * Update the location map in manager
     *
     * @param messageToServer
     */
    @Override
    public void onUnexpectedClientCacheMiss( MessageToServer messageToServer ) {

        ConcurrentMap<Integer,Boolean> blockLocations = Global.server.manager.locationGet( messageToServer.blockId );
        if(blockLocations!=null)
            blockLocations.remove( messageToServer.senderId );
    }

    /**
     * If block is found, send the data back to the client
     * @param result local cache hit result, null if cache miss
     * @param message message redirected to the current client
     * @param client current client
     * @return tnull if the block is not found, or a message containing that block to the original client
     */
    @Override
    public MessageToClient handleRedirectedRequestResult( Block result, MessageToClient message, Client client ) {
        MessageToClient respond = null;
        if (result != null) {//get redirected result

            //global cache hit
            respond = new MessageToClient();
            Global.result.globalCacheHitCount++;
            Block copiedBlock = result.clone();
            respond.senderId = client.id;
            respond.setClientResponse( copiedBlock,message.originalClientId );
            respond.isLastBlockRequest = message.isLastBlockRequest;
        }

        return respond;
    }

    /**
     * No block will be forwarded from other client, so this function is empty in greedy forwarding algorithm
     */
    @Override
    public MessageToClient handleForwardedBlock( Client client, MessageToClient forwardMessage ) {
        Global.result.messageFromClient++;
        return null;
    }

    /**
     * No block will be forwarded from other client, so this function is empty in greedy forwarding algorithm
     */
    @Override
    public int getBlockForwardClient( Client client, Block block ) {
        return -1;
    }
}