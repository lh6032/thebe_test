package cocache.exception;

/**
 * Initialization
 */
public class InitializationException extends Exception{
    public InitializationException( String message ) {
        super( message );
    }
}
