import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ResultValidator {
    private static boolean isBlockSentInOrder(int resultIndex) throws IOException {
        BufferedReader traceReader = new BufferedReader( new FileReader( new File("trace"+resultIndex) ) );
        BufferedReader logReader = new BufferedReader( new FileReader( new File("log"+resultIndex) ) );

        Map<Integer, List<Integer>> requests = new HashMap<>(  );
        Map<Integer, List<Integer>> logs = new HashMap<>(  );

        traceReader.lines().forEach( line->{
            String[] strs = line.split( " " );
            int clientIndex = Integer.parseInt( strs[0] );
            int blockIndex = Integer.parseInt( strs[1] );
            if (requests.containsKey( clientIndex )){
                requests.get( clientIndex ).add( blockIndex );
            }else{
                ArrayList<Integer> list = new ArrayList(  );
                list.add( blockIndex );
                requests.put( clientIndex, list);
            }
        });

        logReader.lines().forEach( line->{
            String strs[] = null;
            if(line.indexOf( "received response of block" )>-1){
                strs = line.split( " received response of block" );
            }else{
                strs = line.split( " local cache hit of block" );
            }

            int clientIndex = Integer.parseInt( strs[0].split( " " )[2].substring( 6 ) );
            int blockIndex = Integer.parseInt( strs[1].split( " " )[0]);
            if (logs.containsKey( clientIndex )){
                logs.get( clientIndex ).add( blockIndex );
            }else{
                ArrayList<Integer> list = new ArrayList(  );
                list.add( blockIndex );
                logs.put( clientIndex, list);
            }
        });


        for(Map.Entry<Integer,List<Integer>> entry: requests.entrySet()){
            int clientId = entry.getKey();
            List<Integer> requestedBlocks = entry.getValue();
            if (logs.containsKey( clientId )){
                List<Integer> logBlocks = logs.get( clientId );

                int size1 = requestedBlocks.size();
                int size2 = logBlocks.size();
                if(size1!=size2) return false;
                for (int i = 0; i < size1; i++) {
                    if(requestedBlocks.get( i ).intValue()!=logBlocks.get( i ).intValue()) return false;
                }
            }else{
                return false;
            }
        }
        return true;
    }

    public static void main( String[] args ) throws IOException {
        int resultIndex = args!=null && args.length==1?Integer.parseInt( args[0] ):-1;
        if(resultIndex>-1){
            boolean res = isBlockSentInOrder(resultIndex);
            System.out.println(res?"All blocks for interation #"+resultIndex+" is valid":("Trace file for iteration #"+resultIndex+" is invalid."));
        }else{
            resultIndex = 0;
            while(true){
                File logFile = new File("log"+resultIndex);
                if(logFile.exists() && !logFile.isDirectory()){
                    boolean res = isBlockSentInOrder(resultIndex);
                    System.out.println(res?"All blocks for interation #"+resultIndex+" is valid":("Trace file for iteration #"+resultIndex+" is invalid."));
                    resultIndex++;
                }else{
                    break;
                }
            }
        }
    }
}
