package cocache;

import cocache.data.Block;
import cocache.entity.*;
import cocache.simulation.Configuration;
import cocache.simulation.Global;
import cocache.simulation.Result;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Deque;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class Start {
    private static final String traceFileName = "trace";

    /**
     * Initialization stage of the simulation
     * <p>
     * Read configurations
     * Generate traces and serialize
     * Create client objects
     * Create globally used objects
     *
     * @throws IOException
     */
    private static void initialization() throws IOException {
        Deque<ClientTrace> traces = Configuration.USE_EXISTING_TRACE_FILE ? Trace.readFile( traceFileName ) :
                Trace.getTraceByCondition( Configuration.REQUEST_PER_CLIENT, Configuration.LOCALIZATION_FACTOR );

        if (!Configuration.USE_EXISTING_TRACE_FILE)
            Trace.toStringAndSave( traces, traceFileName+Global.currentIteration );

        Global.traces = traces;
        Global.clients = new Client[Configuration.CLIENT_NUMBER];

        Global.clientReceivePorts = new int[Configuration.CLIENT_NUMBER];
        Global.clientSenderPortMap = new ConcurrentHashMap<Integer, Integer>();
        Global.serverReceivePorts = new int[Configuration.CLIENT_NUMBER];

        Global.server = Server.getServer();
        for (int i = 0; i < Configuration.CLIENT_NUMBER; i++) {
            Global.clients[i] = new Client( i );
        }

        Global.result = new Result();

        for (ClientTrace trace : Global.traces) {
            Global.clients[trace.clientId].traces.addLast( trace );
        }
        try {
            Global.logWriter = new BufferedWriter( new FileWriter( "log" + Global.currentIteration ) );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Restart the experiment and export the result to a new log file.
     * Called after all the threads and related sockets are closed.
     * <p>
     * Here the client number and request per client may change,
     * so the trace file can not remain the same.
     *
     * @throws IOException
     */
    public static void restart() throws IOException {
        Global.restart();
        Deque<ClientTrace> traces = Configuration.USE_EXISTING_TRACE_FILE ? Trace.readFile( traceFileName ) :
                Trace.getTraceByCondition( Configuration.REQUEST_PER_CLIENT, Configuration.LOCALIZATION_FACTOR );

        if (!Configuration.USE_EXISTING_TRACE_FILE)
            Trace.toStringAndSave( traces, traceFileName+Global.currentIteration );

        Global.traces = traces;
        Global.clients = new Client[Configuration.CLIENT_NUMBER];
        Global.clientReceivePorts = new int[Configuration.CLIENT_NUMBER];
        Global.clientSenderPortMap = new ConcurrentHashMap<Integer, Integer>();
        Global.serverReceivePorts = new int[Configuration.CLIENT_NUMBER];

        Global.server.restart();

        for (int i = 0; i < Configuration.CLIENT_NUMBER; i++) {
            Global.clients[i] = new Client( i );
        }

        for (ClientTrace trace : Global.traces) {
            Global.clients[trace.clientId].traces.addLast( trace );
        }

        Global.result = new Result();

        if (Global.logWriter != null) {
            Global.logWriter.close();
        }

        Global.logWriter = new BufferedWriter( new FileWriter( "log" + Global.currentIteration ) );
    }

    /**
     * According to the current simulation condition,
     * fill in the client caches and server cache with blocks.
     */
    public static void warmUp() {
        switch (Configuration.simulationCondition) {
            case ONLY_LOCAL_CACHE:
                break;
            case ONLY_GLOBAL_CACHE:
                for (int i = 0; i < Global.clients.length; i++) {
                    Global.clients[i].cache.set( new Block( i ) );
                    ConcurrentMap<Integer, Boolean> locationMap = new ConcurrentHashMap<Integer, Boolean>();
                    locationMap.put( i, false );
                    Global.server.manager.location.put( i, locationMap );
                }
                break;
            case ONLY_SERVER_CACHE:
                for (int i = 0; i < Configuration.SERVER_CACHE_SIZE; i++) {
                    Global.server.cache.set( new Block( i ) );
                }
                break;
            case NORMAL:
                Global.algorithm.warmUp();
                break;
        }
    }

    /**
     * Experiment stage
     *
     * Warm up phase is to fill in the caches with blocks.
     * <p>
     * Starting all receivers
     * <p>
     * The last receiver starter thread starts the connection builder.
     * <p>
     * Building all the connections between each client and server
     * <p>
     * The last connection builder thread starts all the client senders.
     * <p>
     * Sending messages and record all the records in the experiment.
     * <p>
     * The last client finishing sending messages closes all the sockets.
     * <p>
     * Entering the next iteration.
     */
    public static void experiment() {
        warmUp();

        // for (int i = 0; i < Global.clients.length; i++) {
        //     new ClientServerReceiverStarter( true, i ).start();
        // }

        new ClientServerReceiverStarter( false, -1 ).start();
    }

    public static void main( String[] args ) throws Exception {
        Configuration.readFromFile( "hint.conf" );
        initialization();
        experiment();
    }
}
