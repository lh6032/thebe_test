package cocache.communication;

import cocache.data.Block;
import cocache.data.BlockAgeTable;

import java.io.Serializable;

/**
 * Message to client
 * Including all types of messages, such as client to client and server to client
 */
public class MessageToClient implements Serializable {
    private static final long serialVersionUID = 41L;

    public boolean isServerDataResponse = false;//response from server with data
    public boolean isClientDataResponse = false;//response from client with data
    public boolean isServerRedirected = false;//redirect request from server with data
    public boolean isClientForwarded = false;//block forwarded from other client,
    public boolean isClientRedirected = false;//message redirected from other client, in case the block is not found in that client and a redirection is needed
    public boolean isLastBlockRequest = false;
    public BlockAgeTable ageTable;

    public Block block;

    //where the respond is send to
    public int clientId = -1;

    //the sender client
    public int senderId = -1;

    public int blockId = -1;
    public int originalClientId = -1;
    public int forwardCount = 0;

    @Override
    public String toString() {
        return "MessageToClient{" +
                "isServerDataResponse=" + isServerDataResponse +
                ", isClientDataResponse=" + isClientDataResponse +
                ", isServerRedirected=" + isServerRedirected +
                ", isClientForwarded=" + isClientForwarded +
                ", block=" + block +
                ", clientId=" + clientId +
                ", senderId=" + senderId +
                ", blockId=" + blockId +
                ", originalClientId=" + originalClientId +
                '}';
    }

    public void setClientResponse( Block block, int clientId){
        this.isClientDataResponse = true;
        this.isServerDataResponse = false;
        this.clientId= clientId;
        this.block = block;
        this.blockId = block.id;
    }

    public void setServerResponse(Block block, int clientId){
        this.isServerDataResponse = true;
        this.block = block;
        this.blockId = block.id;
        this.clientId = clientId;
    }

    public void setRedirectFromServer(int blockId, int originalClientId, int clientId){
        this.blockId = blockId;
        this.clientId = clientId;
        this.originalClientId = originalClientId;
        this.isServerRedirected = true;
    }

    public void setForwardedFromClient(Block block, int nextClientId, int senderId){
        this.clientId = nextClientId;
        this.block = block;
        this.blockId = block.id;
        this.isClientForwarded = true;
        this.senderId = senderId;
    }
}
