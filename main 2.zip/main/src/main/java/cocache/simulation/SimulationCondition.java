package cocache.simulation;

public enum SimulationCondition {
    NORMAL,
    ONLY_LOCAL_CACHE,
    ONLY_GLOBAL_CACHE,
    ONLY_SERVER_CACHE,
    ONLY_SERVER_DISK;
}
