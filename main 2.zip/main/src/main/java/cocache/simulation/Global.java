package cocache.simulation;

import cocache.entity.Client;
import cocache.entity.ClientTrace;
import cocache.entity.Server;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import static cocache.simulation.Configuration.*;

public class Global {
    public static int currentIteration = 0;

    public static AtomicInteger clientPortRequested = new AtomicInteger( 0 );

    public static AtomicInteger startedNodes = new AtomicInteger( 0 );
    public static AtomicInteger connectedClients = new AtomicInteger( 0 );
    public static AtomicInteger readyClients = new AtomicInteger( 0 );

    // number of closed clients
    // clients can start in a linear fashion, but can not close like that
    // so this variable must be thread safe
    public static AtomicInteger closedClients = new AtomicInteger( 0 );
    public static AtomicInteger closedSockets = new AtomicInteger( 0 );

    public static InetAddress localAddress;
    public static int[] clientReceivePorts;
    public static Map<Integer, Integer> clientSenderPortMap;
    public static int[] serverReceivePorts;
    public static int serverTempReceivePort;

    public static Deque<ClientTrace> traces;
    public static Client[] clients;
    public static Server server;

    public static Result result;
    public static Algorithm algorithm;

    //local cache, global cache, server cache
    public static boolean[] cacheAccessibility = new boolean[]{true, true, true};

    public static BufferedWriter logWriter;

    public static AtomicLong printTime = new AtomicLong( 0 );

    public static void restart() {
        clientPortRequested.set( 0 );
        startedNodes.set( 0 );
        connectedClients.set( 0 );
        readyClients.set( 0 );
        closedClients.set( 0 );
        closedSockets.set( 0 );
        printTime.set( 0 );
    }

    public static synchronized void print( String str ) {
        print( str, false );
    }

    public static synchronized void print( String str, boolean isReceivingLog ) {
        if(ONLY_PRINT_RECEIVE_LOG && !isReceivingLog) return;

        try {
            long current = System.currentTimeMillis();
            if (printTime.get() == 0) {
                printTime.set( current );
            }
            str = "T " + (current - printTime.get()) + " " + str;
            logWriter.write( str );
//            System.out.println(str);
            logWriter.newLine();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Close bufferedWriter
     * Summary based on recorded result
     * Output the summary to the corresponding result file.
     */
    public static void summary() throws IOException {
        try {
            logWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        BufferedWriter resultWriter = new BufferedWriter( new FileWriter( "result" + Global.currentIteration ) );
        resultWriter.write( "Configuration" );
        resultWriter.newLine();
        resultWriter.write( "TOTAL_BLOCKS: " + TOTAL_BLOCKS );
        resultWriter.newLine();
        resultWriter.write( "CLIENT_CACHE_SIZE: " + CLIENT_CACHE_SIZE );
        resultWriter.newLine();
        resultWriter.write( "SERVER_CACHE_SIZE: " + SERVER_CACHE_SIZE );
        resultWriter.newLine();
        resultWriter.write( "CLIENT_NUMBER: " + CLIENT_NUMBER );
        resultWriter.newLine();
        resultWriter.write( "REQUEST_PER_CLIENT: " + REQUEST_PER_CLIENT );
        resultWriter.newLine();
        resultWriter.write( "LOCALIZATION_FACTOR: " + LOCALIZATION_FACTOR );
        resultWriter.newLine();
        resultWriter.write( "SIMULATION_CONDITION: " + simulationCondition );

        resultWriter.newLine();
        resultWriter.write( "ALGORITHM: " + ALGORITHM );

        resultWriter.newLine();
        resultWriter.newLine();
        resultWriter.write( "Results" );
        resultWriter.newLine();
        resultWriter.write( "Global cache hit: " + Global.result.globalCacheHitCount );
        resultWriter.newLine();
        resultWriter.write( "Local cache hit: " + Global.result.localCacheHitCount );
        resultWriter.newLine();
        resultWriter.write( "Disk access: " + Global.result.diskAccessCount );
        resultWriter.newLine();
        resultWriter.write( "Server traffic: " + (Global.result.messageToServer + Global.result.messageFromServer) );
        resultWriter.newLine();
        resultWriter.write( "Unexpected cache miss: " + Global.result.unexpectedCacheMiss );
        resultWriter.newLine();
        resultWriter.write( "Unexpected long request: " + Global.result.unexpectedLongRequest );
        resultWriter.newLine();
        resultWriter.write( "Requests that reach the maximum forward threshold: " + Global.result.maximumForwardExceedCount );
        resultWriter.newLine();
        resultWriter.write( "Total request: " + Configuration.REQUEST_PER_CLIENT * Configuration.CLIENT_NUMBER );
        resultWriter.newLine();
        int totalCommunication = Global.result.messageToServer + Global.result.messageToClient;
        resultWriter.write( "Total communication: " + (totalCommunication) );
        resultWriter.newLine();
        int totalCacheHit = Global.result.serverCacheHitCount + Global.result.localCacheHitCount + Global.result.globalCacheHitCount;
        resultWriter.write( "Total cache hit: " + (totalCacheHit) );
        resultWriter.newLine();
        resultWriter.write( "Ticks: " + (totalCommunication * COMMUNICATION_TICK +
                Global.result.localCacheHitCount * LOCAL_CACHE_HIT_TICK +
                Global.result.managerOperationCount * SERVER_MANAGER_OPERATION_TICK +
                Global.result.serverCacheHitCount * SERVER_CACHE_HIT_TICK +
                Global.result.globalCacheHitCount * GLOBAL_CACHE_HIT_TICK +
                Global.result.diskAccessCount * SERVER_DISK_ACCESS_TICK) );
        resultWriter.newLine();
        resultWriter.write( "Hit rate: " + (100.0 * (totalCacheHit) / Configuration.REQUEST_PER_CLIENT / Configuration.CLIENT_NUMBER) );
        resultWriter.newLine();
        resultWriter.close();
    }

    static {
        try {
            localAddress = InetAddress.getByName( "localhost" );
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        ;
    }
}
