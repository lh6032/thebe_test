package cocache.simulation;

public class Result {
    public int messageFromClient = 0;
    public int messageToClient = 0;
    public int messageToServer = 0;
    public int messageFromServer = 0;
    public int localCacheHitCount = 0;
    public int managerOperationCount = 0;
    public int serverCacheHitCount = 0;
    public int globalCacheHitCount = 0;
    public int diskAccessCount = 0;
    public int unexpectedCacheMiss = 0;
    public int maximumForwardExceedCount = 0;
    public int unexpectedLongRequest = 0;
}
