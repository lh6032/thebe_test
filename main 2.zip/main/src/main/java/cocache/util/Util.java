package cocache.util;

import cocache.communication.MessageToClient;
import cocache.entity.ClientReceiverHandler;
import cocache.simulation.Global;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.*;

public class Util {
    public static void checkPort(int port){
        if(port == 80 || port == 443){
            System.out.println("Assigned port:"+port);
            System.exit( 0 );
        }
    }

    public static synchronized void sendAndClose( int clientId, InetAddress address, int destId, Object object ) throws IOException {
        new ClientReceiverHandler( Global.clients[destId],(MessageToClient)object ).start();
//        int destPort = Global.clientReceivePorts[destId];
//        Socket clientSocket = Util.getAvailableSocket( clientId, address, destPort );
//        ObjectOutputStream out = new ObjectOutputStream( clientSocket.getOutputStream() );
//        out.writeObject( object );
//        out.close();
//        clientSocket.close();
    }

    public static synchronized Socket getAvailableSocket( int clientId, InetAddress inetAddress, int port ) {
        Global.clientPortRequested.incrementAndGet();
        Socket clientSocket = new Socket();
        try {
            clientSocket.setReuseAddress( true );
            clientSocket.setSoLinger( false,0 );
            clientSocket.bind( new InetSocketAddress( inetAddress, 0 ) );
            clientSocket.connect( new InetSocketAddress( inetAddress, port ) );
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return clientSocket;
    }
}
