package cocache.entity;

import cocache.communication.MessageToClient;
import cocache.communication.MessageToServer;
import cocache.exception.CommunicationException;
import cocache.simulation.Global;
import cocache.util.Util;

import java.io.*;
import java.net.BindException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;

public class ClientReceiverHandler extends Thread {
    private Socket socket;
    private Client client;
    private MessageToClient incomingMessage;
    private boolean isTemp;

    public ClientReceiverHandler( Client client, Socket socket ) {
        this.isTemp = false;
        this.socket = socket;
        this.client = client;
    }

    public ClientReceiverHandler( Client client, MessageToClient incomingMessage ) {
        this.isTemp = false;
        this.client = client;
        this.incomingMessage = incomingMessage;
    }

    @Override
    public void run() {
        ObjectInputStream in = null;
        MessageToClient message = null;

        if (socket == client.clientSender.toServerSocket) {
            Thread.currentThread().setName( "Client" + client.id + " Receive From Server Thread" );
        }

        try {
            if (socket == client.clientSender.toServerSocket) {
                if (client.clientSender.toServerInputStream == null) {
                    client.clientSender.toServerInputStream = new ObjectInputStream( socket.getInputStream() );
                }
                in = client.clientSender.toServerInputStream;
            } else {
                this.isTemp = true;
                try {
                    if(socket!=null)
                        in = new ObjectInputStream( socket.getInputStream() );
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        } catch (StreamCorruptedException e) {
System.out.println("Current client's socket port is:"+(socket!=null?socket.getLocalPort():-1));
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //for temporary connection, thread will not keep reading further objects thus it only runs once
        int count = 0;
        while (!this.isTemp || count < 1) {
            count++;
            try {
                if (incomingMessage == null){
                    message = (MessageToClient) in.readObject();
                }else{
                    message = incomingMessage;
                }

                //close message for client server connection
                if (socket!=null && (in == null || message == null)) {
                    client.clientSender.writeToOutputStream( null );
                    break;
                }

                if (message.isServerDataResponse) {
                    Global.print( "Client" + client.id + " received response of block" + message.blockId + " from server" , true);

                    MessageToClient forwardMessage = client.receiveBlockRespond( true, message.block );

                    //just accept the last block request without any further forward
                    if (!message.isLastBlockRequest){
                        if (forwardMessage != null) {
                            Util.sendAndClose( client.id,Global.localAddress, forwardMessage.clientId,forwardMessage);
                        }
                    }

                    client.clientSender.interrupt();
                } else if (message.isClientDataResponse) {
                    Global.print( "Client" + client.id + " received response of block" + message.blockId + " from client" + message.senderId , true);

                    MessageToClient forwardMessage = client.receiveBlockRespond( false, message.block );

                    //just accept the last block request without any further forward
                    if(!message.isLastBlockRequest){
                        if (forwardMessage != null) {
                            Util.sendAndClose( client.id,Global.localAddress, forwardMessage.clientId,forwardMessage);
                        }
                    }

                    client.clientSender.interrupt();
                } else if (message.isServerRedirected || message.isClientRedirected) {
                    Global.print( "Client" + client.id + " received redirection of block" + message.blockId + (message.isServerRedirected ?" from server":"from client"+message.senderId) );
                    MessageToClient messageToClient = client.acceptRedirectedRequest( message );

                    //fire and forget
                    if (messageToClient != null) {
                        if(messageToClient.block!=null)
                            Global.print( "Client" + client.id + " has the redirected block" + message.blockId + "  and is sending to client" + messageToClient.clientId );
                        else
                            Global.print( "Client" + client.id + " redirected the block request of block" + message.blockId + " and is sending to client" + messageToClient.clientId );

                        Util.sendAndClose(client.id,Global.localAddress, messageToClient.clientId,messageToClient );
                    } else {//unexpected cache miss
                        //send a special message to server
                        Global.result.unexpectedCacheMiss++;
                        Global.print("Unexpected cache miss happens, client"+client.id+" is requesting block"+message.blockId+" directly from server disk to send it back to client"+message.originalClientId);
                        MessageToServer requestToServer = new MessageToServer( message.blockId, message.originalClientId, true );
                        requestToServer.senderId = client.id;
                        requestToServer.isUnexpectedMiss = true;

                        client.clientSender.writeToOutputStream( requestToServer );
                    }
                } else if (message.isClientForwarded) {
                    MessageToClient messageToClient = client.acceptForwardedBlock( message );
                    Global.print( "Client" + client.id + " received forwarded block" + message.blockId + " from client" + message.senderId +" and is "+(messageToClient==null?"not forwarding":"forwarding to client"+messageToClient.clientId));
                    if(messageToClient!=null){
                        Util.sendAndClose( client.id, Global.localAddress, messageToClient.clientId, messageToClient );
                    }
                }
            } catch (IOException | ClassNotFoundException e) {
                System.out.println("eee "+client.id+" "+isTemp+" "+socket+" "+message+" "+(in == client.clientSender.toServerInputStream));
                e.printStackTrace();
                try {
                    Global.logWriter.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                break;
            }
        }

        try {
            if(this.socket!=null && this.incomingMessage==null){
                this.socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
