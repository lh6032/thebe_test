package cocache.entity;


import cocache.Start;
import cocache.communication.MessageToServer;
import cocache.simulation.Configuration;
import cocache.simulation.Global;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Receiver thread for client.
 * There is only one thread looping through the trace queue.
 * The thread ends after all the clients end sending.
 */
public class ClientSender extends Thread {
    private Client client;
    public AtomicBoolean isClosed = new AtomicBoolean( false );

    //client sender wait after sending a request to the corresponding receiver
    private Object sendLock;
    public Socket toServerSocket = null;
    public ObjectOutputStream toServerOutputStream = null;
    public ObjectInputStream toServerInputStream = null;

    public synchronized void writeToOutputStream(Object object) throws IOException {
        toServerOutputStream.writeObject( object );
        toServerOutputStream.flush();
    }

    /**
     * Use the client to initialize the receiver
     *
     * @param client A client object including the LRU cache of that client
     * @throws SocketException
     */
    public ClientSender( Client client ) throws IOException {
        this.sendLock = new Object();
        this.client = client;
        Thread.currentThread().setName( "Client"+client.id+" Sender Thread" );
    }

    @Override
    public void run() {
        this.isClosed.set( false );
        while(true){
            try{
                MessageToServer requestToServer = null;

                //end of the experiment
                if(client.traces.size() == 0){
                    break;
                }else{
                    //start of the experiment
                    requestToServer = client.consumeTrace( client.traces.pollFirst() );
                    Global.print(requestToServer==null?"Client"+client.id+" local cache hit":"Client"+client.id+" is sending the block"+requestToServer.blockId);
                }

                if (requestToServer!=null){
                    writeToOutputStream( requestToServer );
                    //wait until receive a block with content
                    //no timeout
                    synchronized (sendLock){
                        try {
                            sendLock.wait();
//                            Global.result.unexpectedLongRequest++;
                        } catch (InterruptedException e) {
                            Global.print( "Client"+client.id+"'s sender is going to send the next block" );
                        }
                    }
                }else{
                }
            }catch (IOException  e) {
                e.printStackTrace();
            }
        }

        this.isClosed.set( true );
        Global.print("Client"+client.id+" sender closed");

        try{
            if(Global.closedClients.incrementAndGet() == Global.clients.length){
                Global.print("The all the last message received the corresponding respond. All the other clients'receiver and the server receiver will close");

                //here a close message is sent from server to client
                //in order for the server listening thread to end
                //a corresponding close message is sent from client to server
                //after the server received all the end messages, the current simulation completes closing all sockets and releasing all resources
                for (int i = 0; i < Global.clients.length; i++) {
                    Global.clients[i].clientReceiver.receiveSocket.close();
                }

                for (int i = 0; i < Global.clients.length; i++) {
                    Global.server.serverReceiver.receiveSockets[i].close();
                }

                for (int i = 0; i < Global.clients.length; i++) {
                    if(Global.server.outputStreamMap[i]!=null){
                        Global.server.outputStreamMap[i].writeObject( null );
                    }
                }

            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
