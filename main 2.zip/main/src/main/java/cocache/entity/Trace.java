package cocache.entity;

import cocache.simulation.Configuration;
import cocache.data.Block;
import cocache.exception.InitializationException;

import java.io.*;
import java.util.*;

public class Trace {
    private static void swap(int[] arr, int a, int b){
        int temp = arr[a];
        arr[a] = arr[b];
        arr[b] = temp;
    }

    /**
     * Here we generate special traces for baseline tests
     *
     * NORMAL: normal random traces
     * ONLY_LOCAL_CACHE: same traces for each client
     * NO_LOCAL_CACHE, NO_GLOBAL_CACHE, NO_CACHE: ordered traces for each client
     */
    public static ArrayDeque<ClientTrace> getTraceByCondition(int requestPerClient, int localizationFactor){
        ArrayDeque<ClientTrace> result = new ArrayDeque<ClientTrace>(  );

        switch (Configuration.simulationCondition){
            case ONLY_SERVER_CACHE:
                int k =  0;
                for (int i = 0; i < Configuration.CLIENT_NUMBER; i++) {
                    for (int j = 0; j < requestPerClient; j++,k++) {
                        ClientTrace trace = new ClientTrace( i,new Block( k % Configuration.SERVER_CACHE_SIZE ) );
                        result.addLast( trace );
                    }
                }
                break;
            case ONLY_GLOBAL_CACHE:
                for (int i = 0; i < Configuration.CLIENT_NUMBER; i++) {
                    for (int j = 0; j < requestPerClient; j++) {
                        ClientTrace trace = new ClientTrace( i,new Block( i+1 ) );
                        result.addLast( trace );
                    }
                }
                break;
            case ONLY_SERVER_DISK:
            case NORMAL:
                result = getTrace( requestPerClient, localizationFactor );
                break;

            case ONLY_LOCAL_CACHE:
                for (int i = 0; i < Configuration.CLIENT_NUMBER; i++) {
                    for (int j = 0; j < requestPerClient; j++) {
                        ClientTrace trace = new ClientTrace( i,new Block( i ) );
                        result.addLast( trace );
                    }
                }
                break;

            default:
                for (int i = 0; i < Configuration.CLIENT_NUMBER; i++) {
                    for (int j = 0; j < requestPerClient; j++) {
                        //for each client, they ask block 0 to requestPerClient-1
                        ClientTrace trace = new ClientTrace( i,new Block( j ) );
                        result.addLast( trace );
                    }
                }
                break;
        }

        return result;
    }

    /**
     * Ideally, the blocks required by the clients is distributed evenly over
     * the available blocks.
     *
     * Here we set a variable localization factor to control the distribution of requests.
     *
     * But some blocks are frequently required by a specific client in
     * reality. As a result, Assuming the block space is separated
     * into CLIENT_NUMBER parts.
     *
     * When localization factor is 0, each client only read from its own part
     * When localization factor is 50, each client only read half of its own part,
     * the other half is distributed randomly.
     *
     * When localization factor is 100, all requests are random which means
     * any client may request any block at any time.
     *
     * @param requestPerClient number of requests sent by each client
     * @param localizationFactor Generally, high localization factor represents low locality of data.
     * @return a list of requests consumed by clients
     * @throws InitializationException
     */
    public static ArrayDeque<ClientTrace> getTrace( int requestPerClient, int localizationFactor)
            {
        int totalClients = Configuration.CLIENT_NUMBER;
        int totalBlocks = Configuration.TOTAL_BLOCKS;
        int totalRequests = requestPerClient * totalClients;
        int[] clientIds = new int[totalRequests];
        int[] blockIds = new int[totalRequests];

        //number of localized requests and blocks
        int localizedRequest = requestPerClient * localizationFactor / 100;
        int localizedBlock = (int) Math.ceil( (float) Configuration.TOTAL_BLOCKS / totalClients );

        int lastIndex = -1;

        for (int i = 0; i < totalClients + 1; i++) {
            //fill in the blank of previous non-localized requests
            for (int j = lastIndex + 1; j < i*requestPerClient; j++) {
                clientIds[j] = j %totalClients;
                blockIds[j] = (int) (Math.random() * totalBlocks);
            }

            for (int j = 0; i<totalClients && j < localizedRequest && i*localizedRequest + j < totalRequests; j++) {
                //generate requests for assigned blocks
                clientIds[i*requestPerClient + j] = i;
                blockIds[i*requestPerClient + j] = i * localizedBlock + (int)(Math.random() * localizedBlock);

                lastIndex = i*requestPerClient + j;
            }
        }

        //shuffle
        for (int i = 0; i < totalRequests; i++) {
            int index = (int)(Math.random() * (totalRequests - i)) + i;
            swap(clientIds,i,index);
            swap(blockIds,i,index);
        }

        ArrayDeque<ClientTrace> res = new ArrayDeque<ClientTrace>(  );
        for (int i = 0; i < totalRequests; i++) {
            res.push( new ClientTrace(clientIds[i], new Block(blockIds[i])));
        }

        return res;
    }

    public static Deque<ClientTrace> readFile( String filePath) {
        ArrayDeque<ClientTrace> res = new ArrayDeque<ClientTrace>(  );
        try {
            File file = new File(filePath);
            FileInputStream fis = new FileInputStream(file);
            byte[] data = new byte[(int) file.length()];
            fis.read(data);
            fis.close();
            String[] traceStrs = new String(data).split( "\n" );
            for (int i = 0; i < traceStrs.length; i++) {
                String[] line = traceStrs[i].split( " " );
                int clientId = Integer.parseInt( line[0] );
                int blockId = Integer.parseInt( line[1] );

                res.push( new ClientTrace(clientId, new Block(blockId)));
            }
        } catch (Exception e) {
            System.out.println("Read file error");
            e.printStackTrace();
        }



        return res;
    }

    public static String toStringAndSave( Deque<ClientTrace> traces, String outputToFile){
        StringBuilder sb = new StringBuilder(  );

        //save sorted trace
        Object[] traceArr = traces.toArray();
        Arrays.sort(traceArr , Comparator.comparing(t->((ClientTrace)t).clientId) );
        for (Object trace :
                traceArr) {
            sb.append( ((ClientTrace)trace).clientId).append( " " ).append( ((ClientTrace)trace).block.id ).append( "\n" );
        }

        String res = sb.toString();

        if (outputToFile!=null && outputToFile.length()>0){
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(outputToFile));
                writer.write( res );
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return res;
    }
}
