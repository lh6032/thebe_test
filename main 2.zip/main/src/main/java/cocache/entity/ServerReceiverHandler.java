package cocache.entity;

import cocache.Start;
import cocache.communication.MessageToClient;
import cocache.communication.MessageToServer;
import cocache.simulation.Configuration;
import cocache.simulation.Global;

import java.io.*;
import java.net.Socket;

public class ServerReceiverHandler extends Thread {
    private Socket socket;
    private int clientId = -1;

    public ServerReceiverHandler( Socket socket ) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            ObjectInputStream inputStream = new ObjectInputStream( socket.getInputStream() );
            ObjectOutputStream outputStream = new ObjectOutputStream( socket.getOutputStream() );

            while (true) {
                try {
                    MessageToServer message = (MessageToServer) inputStream.readObject();
                    if(message == null) break;
                    try {

                        //if the accepted socket corresponds to a certain client, then add this to a map
                        synchronized (Global.server) {
                            int clientId = Global.clientSenderPortMap.getOrDefault( socket.getPort(), -1 );
                            if (clientId > -1 && Global.server.outputStreamMap[clientId] == null) {
                                Global.server.outputStreamMap[clientId] = outputStream;
                            }

                            if(message.isHelloMessage) {
                                // System.out.println("Received Hello message of client"+message.senderId);
                                this.clientId = message.senderId;
                                //start all senders after all connection established
                                if (Global.readyClients.incrementAndGet() == Global.clients.length) {
                                    System.out.println("No."+(Global.currentIteration + 1)+" experiment starts to send block requests.");
                                    for (int i = 0; i < Global.clients.length; i++) {
                                        Global.clients[i].clientSender.start();
                                    }
                                }
                                continue;
                            }

                            MessageToClient messageToClient = Global.server.handleMessage( message, message.blockId, message.originalClientId, message.forceDiskAccess );
                            Global.print( "Server received block" + message.blockId + " request from client" + message.senderId + " and will go to Client" + messageToClient.clientId);
                            Global.server.outputStreamMap[messageToClient.clientId].writeObject( messageToClient );
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        System.out.println( "Server sending message error" );
                    }
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }

            socket.close();

            if(Global.closedSockets.incrementAndGet() == Global.clients.length){
                Global.summary();
                Global.currentIteration++;
                System.out.println("The No." + Global.currentIteration + " experiment's completed.");
                if(Global.currentIteration< Configuration.ITERATION_COUNT){
                    Configuration.change();
                    Start.restart();
                    Start.experiment();
                }
            }
        } catch (IOException e) {
            if (e instanceof StreamCorruptedException){
                System.out.println("Input stream corrupted between client"+this.clientId+" and server!");
            }
            e.printStackTrace();
        }

    }
}
