package cocache.entity;

import cocache.simulation.Global;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Manager implementation
 * For simplicify, we do not include notification message as a type of message
 * All the cache change will directly notify the manager.
 */
public class Manager {
    public Map<Integer, ConcurrentMap<Integer,Boolean>> location;
    public Map<Integer, Integer> masterCopyLocation;

    public ConcurrentMap<Integer,Boolean> locationGet(Integer key){
        Global.result.managerOperationCount++;
        return this.location.get( key );
    }

    public void locationPut(Integer key, ConcurrentMap<Integer,Boolean> value){
        Global.result.managerOperationCount++;
        this.location.put( key, value );
    }

    public Manager() {
        this.location = new ConcurrentHashMap<Integer, ConcurrentMap<Integer,Boolean>>(  );
        this.masterCopyLocation = new ConcurrentHashMap<Integer, Integer>(  );
    }
}
