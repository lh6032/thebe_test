package cocache.entity;
import cocache.data.Block;

public class ClientTrace {
    public int clientId;
    public Block block;

    public ClientTrace( int clientId, Block block ) {
        this.clientId = clientId;
        this.block = block;
    }
}
