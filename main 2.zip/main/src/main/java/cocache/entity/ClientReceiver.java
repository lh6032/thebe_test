package cocache.entity;


import cocache.communication.MessageToClient;
import cocache.communication.MessageToServer;
import cocache.data.Block;
import cocache.simulation.Global;
import cocache.util.Util;

import java.io.*;
import java.net.*;
import java.util.concurrent.TimeoutException;

/**
 * Receiver thread for client.
 * Each client has one receiver and every time the client receiver
 * receives a request, there will be a spawned thread to handle the request.
 */
public class ClientReceiver extends Thread {
    private Client client;
    public ServerSocket receiveSocket;

    /**
     * Use the client to initialize the receiver
     * <p>
     * Here we do not generate client sockets between clients in advance
     *
     * @param client A client object including the LRU cache of that client
     * @throws SocketException
     */
    public ClientReceiver( Client client ) throws IOException {
        this.client = client;
        receiveSocket = new ServerSocket( 0 );
        Util.checkPort(receiveSocket.getLocalPort());
        Global.clientReceivePorts[client.id] = receiveSocket.getLocalPort();
        receiveSocket.setSoTimeout( 0 );
    }

    @Override
    public void run() {
        //even all the blocks in sender are sended, there could still be other requests
//        Global.print( "Client" + client.id + " is listening requests" );
//        Thread.currentThread().setName( "Client" + client.id + " Accepting Thread" );

//        while (true) {//each time accepting a new connection from another client, a new thread is used for future communication
//            try {
//                new ClientReceiverHandler( client, receiveSocket.accept() ).start();
//                System.out.println(client.id);
//            } catch (SocketException e) {//interrupted when current round ends
//                e.printStackTrace();
//                break;
//            }catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        Global.print( "Client" + client.id + " receiver closed" );
    }
}
