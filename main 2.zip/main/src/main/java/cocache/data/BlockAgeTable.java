package cocache.data;

import cocache.entity.Client;
import cocache.simulation.Global;

import java.io.Serializable;

public class BlockAgeTable implements Serializable {
    private static final long serialVersionUID = 42L;

    public int[] ageTable;
    private transient Client client;

    public BlockAgeTable( Client client) {
        this.ageTable = new int[Global.clients.length];
        this.client = client;
    }

    /**
     * update the oldest age of the current client in the table
     */
    public void update(){
        Block last = client.cache.peek();
        if(last!=null){
            this.ageTable[client.id] = Math.max(this.ageTable[client.id], last.age);
        }
    }

    /**
     * Update block age information from the current block age table
     * @param another
     */
    public void exchange(BlockAgeTable another){
        for (int i = 0; i < Global.clients.length; i++) {
            this.ageTable[i] = Math.max(another.ageTable[i], this.ageTable[i]);
        }
    }

    /**
     * compare the block age and find which client holds the oldest block
     * @return id of the client that has the oldest block
     */
    public int getOldestBlockClientId(){
        int res = -1, age = Integer.MAX_VALUE;
        for (int i = 0; i < Global.clients.length; i++) {
            if(ageTable[i]<age){
                age = ageTable[i];
                res = i;
            }
        }

        return res;
    }
}
