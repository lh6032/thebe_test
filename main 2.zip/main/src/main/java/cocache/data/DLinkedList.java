package cocache.data;

/**
 * Double linked list strucure
 * @param <T>
 */
public class DLinkedList<T> {
    public T element;
    public DLinkedList<T> prev;
    public DLinkedList<T> next;

    public DLinkedList(T element) {
        this.element = element;
        prev = null;
        next = null;
    }

    public DLinkedList() {
        element = null;
        prev = null;
        next = null;
    }

    public void moveOut(){
        if(prev!=null)
            prev.next = next;

        if(next !=null)
            next.prev = prev;

        next = null;
        prev = null;
    }
}
