package cocache.data;

import java.util.*;

/**
 * Standard LRU HashMap used for test and compare
 *
 * ref: https://leetcode.com/problems/lru-cache/solution/
 */
public class LRU_LinkedHashMap {
    private int capacity;
    public LinkedHashMap<Integer,Integer> map;

    @Override
    public String toString() {
        Iterator<Integer> iterator = map.keySet().iterator();
        List<Integer> res = new ArrayList<Integer>(  );
        while (iterator.hasNext()){
            res.add( iterator.next() );
        }
        res.sort( Comparator.naturalOrder() );
        return res.toString();
    }

    public LRU_LinkedHashMap( int capacity) {
        this.capacity = capacity;
        this.map = new LinkedHashMap<Integer, Integer>(16, 0.75f, true);
    }

    public int get(int key) {
        Integer value = this.map.get(key);
        if (value == null) {
            value = -1;
        }
        return value;
    }

    public void put(int key, int value) {
        if (
                !this.map.containsKey(key) &&
                        this.map.size() == this.capacity
        ) {
            Iterator<Integer> it = this.map.keySet().iterator();
            it.next();
            it.remove();
        }
        this.map.put(key, value);
    }
}
