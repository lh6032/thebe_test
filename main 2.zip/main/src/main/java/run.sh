#!/bin/bash

javac -d out -Xlint:unchecked ./**/*.java
cp ../resource/hint.conf out
cd out
java cocache.Start